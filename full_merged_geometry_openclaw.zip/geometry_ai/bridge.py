from geometry_native_ai.orchestrator import solve_geometry

def solve(prompt: str):
    result = solve_geometry(prompt)
    return {
        "valid": result.get("valid"),
        "proof": result.get("proof_trace"),
        "explanation": result.get("explanation")
    }
