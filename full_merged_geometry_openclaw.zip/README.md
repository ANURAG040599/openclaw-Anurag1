# Full Merged Geometry + OpenClaw Repo

This repo is pre-wired for integration.

## Included
- Geometry Agent
- Bridge layer
- FastAPI server

## Required (already structured)
- openclaw/ (agent system)
- geometry_native_ai/ (core engine)

## Run
pip install -r requirements.txt
uvicorn app:app --reload
