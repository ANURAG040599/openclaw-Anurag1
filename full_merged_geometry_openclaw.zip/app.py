from fastapi import FastAPI
from agents.geometry_agent.executor import execute

app = FastAPI()

@app.post("/solve_geometry")
def solve_geometry(payload: dict):
    return execute(payload)
