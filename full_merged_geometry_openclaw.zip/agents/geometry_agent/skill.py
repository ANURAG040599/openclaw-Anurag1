from geometry_ai.bridge import solve

class GeometrySkill:
    name = "geometry_solver"
    description = "Solve geometry problems with proof verification"

    def run(self, input_text: str):
        return solve(input_text)
