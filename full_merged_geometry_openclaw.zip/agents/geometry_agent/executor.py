from .skill import GeometrySkill

def execute(params):
    skill = GeometrySkill()
    return skill.run(params["prompt"])
